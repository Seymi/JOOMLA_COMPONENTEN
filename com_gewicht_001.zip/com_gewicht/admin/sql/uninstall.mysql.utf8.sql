DROP TABLE IF EXISTS `#__gewicht`;
DROP TABLE IF EXISTS `#__ereignisse`;
