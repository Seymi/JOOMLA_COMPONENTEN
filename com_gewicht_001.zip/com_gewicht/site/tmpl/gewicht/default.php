<?php

use Joomla\CMS\Language\Text;

/**
 * @package     Joomla.Administrator
 * @subpackage  com_gewicht
 *
 * @copyright   Copyright (C) 2023 Martin Seymann. All rights reserved.
 * @license     GNU General Public License version 3
 */

 // No direct access to this file
defined('_JEXEC') or die('Restricted Access');
?>

<h2>Gewicht</h2>
