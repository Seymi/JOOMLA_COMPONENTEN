DROP TABLE IF EXISTS `#__custompage_greetings`;
